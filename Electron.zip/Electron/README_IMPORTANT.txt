Hello Thanks for downloading Electron

If you have problem with Electron please go to, https://ryos.best/forum/public/d/11-fixes-and-tutorial

Official discord server: https://discord.io/EJIT
Please join our forum here, https://ryos.best/forum